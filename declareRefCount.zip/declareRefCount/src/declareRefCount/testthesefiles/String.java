package declareRefCount;

public class String {

}

String dog;
String cat;
String man;
String doe;