package declareRefCount;

public class Entry {
	Entry emp;
	Entry ent;
	Entry EMPO;
}
public class Entry
